tweak_data.projectiles.frag_cluster = {}
tweak_data.projectiles.frag_cluster = deep_clone(tweak_data.projectiles.concussion)
tweak_data.projectiles.frag_cluster.name_id = "bm_throw_frag_cluster"
tweak_data.projectiles.frag_cluster.custom = true