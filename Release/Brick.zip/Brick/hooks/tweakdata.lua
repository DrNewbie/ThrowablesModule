tweak_data.projectiles.wpn_prj_brick = {
	range = 100,
	damage = 110,
	launch_speed = 1000,
	adjust_z = 120,
	mass_look_up_modifier = 1,
	name_id = "bm_grenade_prj_brick",
	push_at_body_index = "dynamic_body_spinn",
	bullet_class = "InstantBrickBase",
	sounds = {}
}