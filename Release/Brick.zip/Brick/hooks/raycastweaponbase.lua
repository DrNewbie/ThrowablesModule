InstantBrickBase = InstantBrickBase or class(InstantExplosiveBulletBase)
InstantBrickBase.id = "wpn_prj_brick"